from flask import Flask, render_template, request, redirect, url_for
from docx import Document

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/form', methods=['GET', 'POST'])
def form():
    if request.method == 'POST':
        data = request.form
        doc = Document()
        doc.add_heading('Resume', 0)

        doc.add_heading('Name:', level=1)
        doc.add_paragraph(data['name'])

        doc.add_heading('Email:', level=1)
        doc.add_paragraph(data['email'])

        doc.add_heading('Phone:', level=1)
        doc.add_paragraph(data['phone'])

        doc.add_heading('LinkedIn:', level=1)
        doc.add_paragraph(data['linkedin'])

        doc.add_heading('GitHub:', level=1)
        doc.add_paragraph(data['github'])

        doc.add_heading('Portfolio:', level=1)
        doc.add_paragraph(data['portfolio'])

        doc.add_heading('Education:', level=1)
        doc.add_paragraph(data['education'])

        doc.add_heading('Work Experience:', level=1)
        doc.add_paragraph(data['experience'])

        doc.add_heading('Skills:', level=1)
        doc.add_paragraph(data['skills'])

        doc.add_heading('Projects:', level=1)
        doc.add_paragraph(data['projects'])

        doc.add_heading('Certifications:', level=1)
        doc.add_paragraph(data['certifications'])

        doc.add_heading('Languages:', level=1)
        doc.add_paragraph(data['languages'])

        doc.save(f"{data['name']}_resume.docx")
        return redirect(url_for('home'))
    return render_template('form.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/faq')
def faq():
    return render_template('faq.html')

if __name__ == '__main__':
    app.run(debug=True)
